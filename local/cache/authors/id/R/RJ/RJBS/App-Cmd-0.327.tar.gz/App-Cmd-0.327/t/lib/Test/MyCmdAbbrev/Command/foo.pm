package Test::MyCmdAbbrev::Command::foo;

use strict;
use warnings;

use base qw{ App::Cmd::Command };

1;

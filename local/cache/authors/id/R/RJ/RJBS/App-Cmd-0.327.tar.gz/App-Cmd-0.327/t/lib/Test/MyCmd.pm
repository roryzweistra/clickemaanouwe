package Test::MyCmd;

use strict;
use warnings;

use base qw(App::Cmd);

our $VERSION = '0.123';

1;

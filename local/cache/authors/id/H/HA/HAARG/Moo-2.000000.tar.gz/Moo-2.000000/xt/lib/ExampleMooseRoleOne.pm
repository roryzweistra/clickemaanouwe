package ExampleMooseRoleOne;
use Moose::Role;

1;

